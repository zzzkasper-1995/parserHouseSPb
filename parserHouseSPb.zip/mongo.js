const mongoose = require('mongoose');
const fs=require("fs");
const winston = require('winston');

const Schema = mongoose.Schema;
const House = require('./houseSchema');

const logger = require('./log')(module);

mongoose.connect('mongodb://localhost/houseDB', function (err) {
	if(err) {
		logger.error(`ошибка при подключении к БД: ${err.message}`);
		throw err;   
   }
		
	logger.info('Подключение пршло успешно');
	
	if (!fs.existsSync('./html/main.json')) {
		logger.error('./html/main.json not exist!');
		return 0;
	}

	const dataText = fs.readFileSync('./html/main.json', 'utf-8');
	const houses = JSON.parse(dataText);

	logger.info('Начал просмотр всех имеющихся записей');
	houses.forEach(element => {
		logger.info(`дом ${element.url}`);

		const jsonFileName = `./html/${element.url.split('/')[3]}.json`;
		if (fs.existsSync(jsonFileName)) {			
			const supportInfoText = fs.readFileSync(jsonFileName, 'utf-8');
			const supportInfo = JSON.parse(supportInfoText);
			element.geometry = supportInfo.coordinates;
			element.supportInfo = supportInfo;
		} else {
			logger.error(`${jsonFileName} not exist!`);
			element.geometry = [];
			element.supportInfo = {};
		}
		
		const house = new House ({
			url: element.url,
			address: element.address,
			square: element.square,
			year: element.year,
			floors: element.floors,
			managestartdate: element.managestartdate,
			geometry: { coordinates: element.geometry },
			supportInfo: { },
		});

		// заполняем поле дополнительной информации
		Object.keys(element.supportInfo).forEach(key => {
			//ключ храним в закодированом виде потому что мангуст не терпит ключи со спец знаками (. , * ` ...)
			house.supportInfo.set(Buffer.from(key).toString('base64'), element.supportInfo[key]);
		});
	
		house.save(function(err) {
			logger.info(`Сейчас буду сохранять ${element.url}`);
	    if(err) {
				logger.error(`Ошибка при сохранении записи о доме ${element.url}: ${err.message}`);
				throw err;   
	    }
			logger.info(`Дом соответствующий файлу ${jsonFileName} сохранен в БД`);
		});
	});

});